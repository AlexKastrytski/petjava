package com.example.springdockersimple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDockerSimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
