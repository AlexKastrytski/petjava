package com.example.springdockersimple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDockerSimpleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDockerSimpleApplication.class, args);
	}

}
