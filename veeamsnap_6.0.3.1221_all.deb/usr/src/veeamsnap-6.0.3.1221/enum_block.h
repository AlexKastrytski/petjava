// Copyright (c) Veeam Software Group GmbH

#pragma once

void enum_block_print_state(void);
