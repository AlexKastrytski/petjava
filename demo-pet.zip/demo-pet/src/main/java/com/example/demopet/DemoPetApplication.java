package com.example.demopet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPetApplication.class, args);
	}

}
