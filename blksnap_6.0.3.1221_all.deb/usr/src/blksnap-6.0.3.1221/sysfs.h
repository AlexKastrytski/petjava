/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __BLK_SNAP_SYSFS_H
#define __BLK_SNAP_SYSFS_H

int sysfs_init(void);
void sysfs_done(void);
#endif /* __BLK_SNAP_SYSFS_H */
