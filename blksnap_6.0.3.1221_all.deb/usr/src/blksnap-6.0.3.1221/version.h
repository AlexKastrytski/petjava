/* SPDX-License-Identifier: GPL-2.0 */
#pragma once
#define VERSION_MAJOR	6
#define VERSION_MINOR	0
#define VERSION_REVISION	3
#define VERSION_BUILD	1221
#define VERSION_STR	"6.0.3.1221"
